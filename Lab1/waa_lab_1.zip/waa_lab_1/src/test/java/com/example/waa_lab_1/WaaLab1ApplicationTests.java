package com.example.waa_lab_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaaLab1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
